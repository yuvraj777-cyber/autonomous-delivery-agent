# grid.py
# Simple Grid environment loader and helper functions
from collections import namedtuple

Pos = namedtuple("Pos", ["r", "c"])

class Grid:
    """
    Grid loaded from a text file.
    Format: rows lines, each line has space-separated tokens:
      - integer >=1 : movement cost
      - X : static obstacle (impassable)
      - S : start (treated as cost 1)
      - G : goal  (treated as cost 1)
    Coordinates: row, col starting at 0.
    """
    def __init__(self, filename):
        self.grid = []
        self.rows = 0
        self.cols = 0
        self.start = None
        self.goal = None
        self._load(filename)

    def _load(self, filename):
        with open(filename, "r") as f:
            lines = [ln.strip() for ln in f if ln.strip()]
        for r, ln in enumerate(lines):
            tokens = ln.split()
            if r == 0:
                self.cols = len(tokens)
            self.grid.append(tokens)
        self.rows = len(self.grid)
        for r in range(self.rows):
            for c in range(self.cols):
                t = self.grid[r][c]
                if t == "S":
                    self.start = Pos(r, c)
                    self.grid[r][c] = "1"
                elif t == "G":
                    self.goal = Pos(r, c)
                    self.grid[r][c] = "1"

    def in_bounds(self, p):
        return 0 <= p.r < self.rows and 0 <= p.c < self.cols

    def passable(self, p):
        return self.grid[p.r][p.c] != "X"

    def cost(self, p):
        v = self.grid[p.r][p.c]
        try:
            return int(v)
        except:
            return 1

    def neighbors(self, p):
        # 4-connected movement
        for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
            np = Pos(p.r + dr, p.c + dc)
            if self.in_bounds(np) and self.passable(np):
                yield np

    def display_path(self, path, obstacles=None):
        # returns a string visualizing grid with path (P) and obstacles (M)
        out = []
        pathset = set(path) if path else set()
        obsset = set(obstacles) if obstacles else set()
        for r in range(self.rows):
            row = []
            for c in range(self.cols):
                p = Pos(r,c)
                if p in obsset:
                    row.append("M")  # moving obstacle
                elif p in pathset:
                    if p == self.start:
                        row.append("S")
                    elif p == self.goal:
                        row.append("G")
                    else:
                        row.append("P")
                else:
                    v = self.grid[r][c]
                    row.append(v if v != "1" else ".")
            out.append(" ".join(row))
        return "\n".join(out)
