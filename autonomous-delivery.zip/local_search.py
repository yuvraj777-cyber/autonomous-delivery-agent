# local_search.py
"""
A simple waypoint-based local search / random-restart replanner.
Given a current node and goal, it attempts several random intermediate waypoints,
runs A* from current->waypoint and waypoint->goal, and picks the best combined path.
"""
import random
from search import astar
from grid import Pos

def join_paths(p1, p2):
    if not p1: return p2
    if not p2: return p1
    return p1 + p2[1:]

def local_replan(grid, current, goal, tries=15):
    # baseline: direct A*
    original_start = grid.start
    original_goal = grid.goal
    grid.start = current
    grid.goal = goal
    best_path, nodes, t, cost = astar(grid)
    best_cost = cost
    best_nodes = nodes
    best_path_final = best_path
    # Try random waypoints
    for _ in range(tries):
        r = random.randrange(0, grid.rows)
        c = random.randrange(0, grid.cols)
        wp = Pos(r, c)
        if not grid.passable(wp):
            continue
        # current -> waypoint
        grid.start = current
        grid.goal = wp
        p1, n1, t1, c1 = astar(grid)
        if p1 is None:
            continue
        # waypoint -> goal
        grid.start = wp
        grid.goal = goal
        p2, n2, t2, c2 = astar(grid)
        if p2 is None:
            continue
        combined = join_paths(p1, p2)
        combined_cost = sum(grid.cost(p) for p in combined)
        if combined_cost < best_cost:
            best_cost = combined_cost
            best_path_final = combined
            best_nodes = n1 + n2
    # restore
    grid.start = original_start
    grid.goal = original_goal
    return best_path_final, best_nodes, best_cost
