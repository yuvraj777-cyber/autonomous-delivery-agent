# utils.py
import time

class SimpleLogger:
    def __init__(self):
        self.events = []

    def log(self, msg):
        ts = time.strftime("%H:%M:%S")
        line = f"{ts} - {msg}"
        self.events.append(line)
        print(line)

    def dump(self, filename):
        with open(filename, "w") as f:
            for e in self.events:
                f.write(e + "\n")
