# Report template: Autonomous Delivery Agent in a 2D Grid City

Author: <Your name>
Course: CSA2001 - Fundamentals of AI and ML
Date: <date>

## Abstract
This project implements an autonomous delivery agent that navigates a 2D grid city to deliver packages while handling static obstacles, varying terrain costs, and deterministic moving obstacles. The agent uses multiple planning strategies — BFS, Uniform-Cost Search (UCS), A* with an admissible heuristic, and a simple local-search based replanning strategy — and the performance of each method is compared experimentally on several map instances.

## Environment model
The environment is represented as a rectangular grid where each cell stores either an integer movement cost (≥1) or a static obstacle denoted by 'X'. The agent can move in four directions. The grid files use a simple plaintext format where 'S' marks the start and 'G' marks the goal. Moving obstacles are specified in a schedule file where each line lists a timestep and grid coordinates occupied by a moving obstacle at that time.

## Agent design
The agent acts according to a selected planner (BFS, UCS, A*, or Local). It plans an initial path and executes step-by-step, checking moving obstacles at each timestep. If the next position is occupied, the agent replans from the last safe position.

## Heuristic
A* uses Manhattan distance (admissible because min cost per step = 1). The local method uses random waypoints plus A* on segments.

## Experimental setup
Run each planner on the provided maps and record: path cost, nodes expanded, planning time. For the dynamic map, record replanning events.

## Results
(Insert tables and plots here after running experiments.)

## Analysis
(Discuss when each method performs better and why. A* usually expands fewer nodes than UCS for similar optimality; BFS is only good when costs uniform. Local replanning can quickly find alternative paths when dynamic changes are frequent.)

## Conclusion
(Summarize strengths, weaknesses, and possible improvements such as incremental search, richer heuristics, or prediction of moving obstacles.)

## Appendix
- Include a sample `run_log.txt` showing a replanning event.
