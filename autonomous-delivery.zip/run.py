# run.py
import argparse
from grid import Grid, Pos
from agent import Agent
from utils import SimpleLogger
import os

def load_schedule(filename):
    # schedule file format: each line is "t r c" meaning at time t the moving obstacle occupies r,c
    schedule = {}
    if not os.path.exists(filename):
        return schedule
    with open(filename, "r") as f:
        for ln in f:
            ln = ln.strip()
            if not ln: continue
            parts = ln.split()
            if len(parts) < 3: continue
            t, r, c = parts[:3]
            try:
                t = int(t); r = int(r); c = int(c)
            except:
                continue
            schedule.setdefault(t, set()).add(Pos(r, c))
    return schedule

def main():
    parser = argparse.ArgumentParser(description="Autonomous Delivery Agent Simulator")
    parser.add_argument("--map", type=str, default="maps/small_map.txt", help="map file")
    parser.add_argument("--schedule", type=str, default="schedules/dynamic_schedule.txt", help="moving obstacle schedule")
    parser.add_argument("--algo", type=str, default="astar", choices=["bfs","ucs","astar","local"], help="planner")
    parser.add_argument("--visualize", action="store_true", help="print final path map")
    args = parser.parse_args()

    grid = Grid(args.map)
    schedule = load_schedule(args.schedule)
    logger = SimpleLogger()
    agent = Agent(grid, schedule=schedule, planner=args.algo, logger=logger)
    logger.log(f"Loaded map {args.map}, start={grid.start}, goal={grid.goal}, algo={args.algo}")
    result = agent.step_execute()
    if result:
        logger.log(f"Finished run. Cost: {result.get('cost')}, nodes_expanded: {result.get('nodes')}, time: {result.get('duration'):.4f}s")
        if args.visualize:
            path = result.get('path')
            # Show the obstacles at time 0 for visualization (example)
            print("\nFinal map with path (P) and moving obstacles (M):")
            first_obs = schedule.get(0, set())
            print(grid.display_path(path, obstacles=first_obs))
    else:
        logger.log("No result (failed to reach goal).")
    logger.dump("run_log.txt")

if __name__ == "__main__":
    main()
