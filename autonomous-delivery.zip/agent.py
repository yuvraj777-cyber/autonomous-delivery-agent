# agent.py
import time
from grid import Pos
from search import bfs, ucs, astar
from local_search import local_replan

class Agent:
    """
    Execute a path step-by-step; if a moving obstacle occupies next step at that time,
    trigger replanning using chosen strategy.
    schedule: dict mapping timestep->set of Pos occupied by moving obstacles.
    """
    def __init__(self, grid, schedule=None, planner="astar", logger=None):
        self.grid = grid
        self.schedule = schedule if schedule else {}
        self.timestep = 0
        self.planner = planner
        self.logger = logger

    def plan_once(self):
        if self.planner == "bfs":
            return bfs(self.grid)
        elif self.planner == "ucs":
            return ucs(self.grid)
        elif self.planner == "astar":
            return astar(self.grid)
        elif self.planner == "local":
            return astar(self.grid)
        else:
            return astar(self.grid)

    def step_execute(self):
        # plan initial path
        path, nodes, duration, cost = self.plan_once()
        if path is None:
            self.logger and self.logger.log("No initial path found.")
            return None
        pos_index = 0
        log = []
        while pos_index < len(path):
            cur_pos = path[pos_index]
            # check occupation of current pos at this timestep
            occ = self.schedule.get(self.timestep, set())
            if cur_pos in occ:
                self.logger and self.logger.log(f"[t={self.timestep}] Obstacle at {cur_pos}, replanning.")
                start = path[max(0, pos_index-1)]
                self.grid.start = start
                # If using local planner, call the local_replan function
                if self.planner == "local":
                    new_path, nodes_used, new_cost = local_replan(self.grid, start, self.grid.goal)
                    if new_path:
                        path = new_path
                        pos_index = 0
                        log.append((self.timestep, "replan_local", start, len(new_path)))
                        continue
                    else:
                        log.append((self.timestep, "replan_failed", start))
                        return None
                else:
                    # run chosen planner from 'start'
                    if self.planner == "bfs":
                        new_path, nodes, dur, cost = bfs(self.grid)
                    elif self.planner == "ucs":
                        new_path, nodes, dur, cost = ucs(self.grid)
                    else:
                        new_path, nodes, dur, cost = astar(self.grid)
                    if new_path:
                        path = new_path
                        pos_index = 0
                        log.append((self.timestep, "replan", start, len(new_path)))
                        continue
                    else:
                        log.append((self.timestep, "replan_failed", start))
                        return None
            # normal move (we treat cur_pos as agent position)
            log.append((self.timestep, "move", cur_pos))
            pos_index += 1
            self.timestep += 1
            if cur_pos == self.grid.goal:
                self.logger and self.logger.log(f"Reached goal at time {self.timestep}.")
                return {"path": path, "log": log, "nodes": nodes, "duration": duration, "cost": cost}
        return {"path": path, "log": log, "nodes": nodes, "duration": duration, "cost": cost}
